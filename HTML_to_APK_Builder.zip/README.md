# HTML to APK Builder

A self-hostable HTML-to-Android-APK web app with custom app icons.

## How it works
- Frontend: static website (`public/`) suitable for Netlify.
- Backend: Node.js API (`server/`) that accepts an `.html` file or `.zip` website bundle, plus an optional PNG/JPG icon.
- The backend creates a temporary Capacitor Android project, copies the website into it, applies the custom launcher icon, and builds a **debug APK**.
- APKs are returned for download and temporary build folders are removed.

> This produces installable **debug APKs** for testing/sharing. Publishing to Google Play generally requires a properly signed release/AAB, package-name management, privacy disclosures, and compliance with Play policies. Do not upload private or sensitive website files to a public instance.

## Deploy architecture
You need a build server with Java 17 and Android SDK. Netlify alone cannot compile APKs.
1. Deploy `public/` to Netlify (or any static host).
2. Deploy `server/` to a Docker-capable host (Render paid service, VPS, etc.) using `server/Dockerfile`. A Render blueprint is included in `render.yaml`.
3. Set frontend environment/config `API_BASE_URL` in `public/config.js` to your backend URL.
4. Set backend environment variables:
   - `PORT=3000`
   - `MAX_UPLOAD_MB=25`
   - `ALLOWED_ORIGIN=https://your-site.netlify.app` (or `*` for development only)
5. In backend service, ensure enough disk/RAM/time for Android Gradle builds. First builds may take several minutes.

## Input format
- `.html`: one standalone HTML file; referenced local assets won't be included unless embedded in the HTML.
- `.zip`: a website bundle containing `index.html` at its root or one folder deep, plus CSS/JS/images/fonts. Keep it under the configured upload limit.
- Icon: square PNG recommended, 512×512. JPG is accepted and converted. Transparent icons are supported.

## Important limitations
- This starter uses Capacitor's Android project generation at build time and produces a debug APK.
- A single HTML file cannot magically include local CSS/images that were never uploaded. Upload a ZIP for full websites.
- Treat uploaded HTML/ZIP files as untrusted. The server validates archive paths and file count, but public deployment should add authentication, rate limiting, malware scanning, and per-user quotas.
