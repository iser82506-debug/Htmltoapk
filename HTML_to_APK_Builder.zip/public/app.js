const $=id=>document.getElementById(id);
const siteFile=$('siteFile'), iconFile=$('iconFile'), buildBtn=$('buildBtn'), statusEl=$('status');
let selectedSite=null, selectedIcon=null, downloadUrl=null;
siteFile.addEventListener('change',()=>{selectedSite=siteFile.files[0]||null;$('siteName').textContent=selectedSite?selectedSite.name:'Drop your files here';buildBtn.disabled=!selectedSite;resetResult();});
iconFile.addEventListener('change',()=>{selectedIcon=iconFile.files[0]||null;if(selectedIcon){const img=document.createElement('img');img.alt='Selected app icon';img.src=URL.createObjectURL(selectedIcon);$('iconPreview').replaceChildren(img);}else $('iconPreview').innerHTML='<span>＋</span><small>APP ICON</small>';});
const dz=$('siteDrop');
['dragenter','dragover'].forEach(e=>dz.addEventListener(e,ev=>{ev.preventDefault();dz.classList.add('drag')}));
['dragleave','drop'].forEach(e=>dz.addEventListener(e,ev=>{ev.preventDefault();dz.classList.remove('drag')}));
dz.addEventListener('drop',ev=>{const f=ev.dataTransfer.files[0];if(f&&/\.(html?|zip)$/i.test(f.name)){const dt=new DataTransfer();dt.items.add(f);siteFile.files=dt.files;siteFile.dispatchEvent(new Event('change'));}});
function resetResult(){if(downloadUrl)URL.revokeObjectURL(downloadUrl);downloadUrl=null;$('result').hidden=true;statusEl.textContent='';statusEl.className='status';}
function packageValid(v){return /^[a-zA-Z][a-zA-Z0-9_]*(\.[a-zA-Z][a-zA-Z0-9_]*){1,}$/.test(v);}
buildBtn.addEventListener('click',async()=>{
 if(!selectedSite)return;
 const name=$('appName').value.trim()||'My Web App', pkg=$('packageId').value.trim();
 if(!packageValid(pkg)){statusEl.className='status error';statusEl.textContent='Package ID must look like com.example.myapp (letters, numbers, underscores and dots).';return;}
 if(selectedIcon&&!/^image\/(png|jpeg|webp)$/.test(selectedIcon.type)){statusEl.className='status error';statusEl.textContent='Please choose a PNG, JPG or WebP icon.';return;}
 resetResult();buildBtn.disabled=true;buildBtn.querySelector('span').textContent='Building your APK…';statusEl.textContent='Uploading files and preparing the Android build. This can take several minutes.';
 const fd=new FormData();fd.append('website',selectedSite);fd.append('appName',name);fd.append('packageId',pkg);if(selectedIcon)fd.append('icon',selectedIcon);
 try{
  const base=(window.APKFORGE_CONFIG?.API_BASE_URL||'').replace(/\/$/,'');
  const response=await fetch(base+'/api/build',{method:'POST',body:fd});
  if(!response.ok){let message='Build failed. Please try again.';try{const data=await response.json();message=data.error||message;}catch{}throw new Error(message);}
  const blob=await response.blob();downloadUrl=URL.createObjectURL(blob);
  const a=$('downloadLink');a.href=downloadUrl;a.download=(name.replace(/[^a-z0-9_-]/gi,'_')||'app')+'.apk';
  $('resultText').textContent='APK built successfully. On Android, open the downloaded file to install it.';$('result').hidden=false;statusEl.textContent='Build complete.';
 }catch(err){statusEl.className='status error';statusEl.textContent=err.message||'Could not connect to the build server. Check API_BASE_URL.';}
 finally{buildBtn.disabled=!selectedSite;buildBtn.querySelector('span').textContent='Build my APK';}
});
