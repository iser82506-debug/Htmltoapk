// Set this to your deployed backend URL, e.g. https://your-api.onrender.com
window.APKFORGE_CONFIG = { API_BASE_URL: "http://localhost:3000" };
