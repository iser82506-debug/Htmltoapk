import express from 'express';
import cors from 'cors';
import multer from 'multer';
import AdmZip from 'adm-zip';
import sharp from 'sharp';
import {fileTypeFromBuffer} from 'file-type';
import {promises as fs} from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {spawn} from 'node:child_process';
import crypto from 'node:crypto';

const app=express();
const PORT=Number(process.env.PORT||3000);
const MAX_MB=Math.max(1,Number(process.env.MAX_UPLOAD_MB||25));
const allowedOrigin=process.env.ALLOWED_ORIGIN||'*';
app.use(cors({origin:allowedOrigin==='*'?true:allowedOrigin.split(',').map(s=>s.trim())}));
app.get('/api/health',(_,res)=>res.json({ok:true,service:'APKForge builder'}));
const upload=multer({storage:multer.memoryStorage(),limits:{fileSize:MAX_MB*1024*1024,files:2}});
const run=(cmd,args,cwd,timeout=8*60*1000)=>new Promise((resolve,reject)=>{
 const child=spawn(cmd,args,{cwd,env:{...process.env,CI:'1',ANDROID_HOME:process.env.ANDROID_HOME||'/opt/android-sdk',ANDROID_SDK_ROOT:process.env.ANDROID_SDK_ROOT||'/opt/android-sdk'},stdio:['ignore','pipe','pipe']});
 let out='',err='';child.stdout.on('data',d=>out+=d.toString());child.stderr.on('data',d=>err+=d.toString());
 const timer=setTimeout(()=>{child.kill('SIGKILL');reject(new Error('Build timed out. Please try again later.'));},timeout);
 child.on('error',e=>{clearTimeout(timer);reject(e)});child.on('close',code=>{clearTimeout(timer);if(code===0)resolve(out+'\n'+err);else reject(new Error((err||out).slice(-3500)||`${cmd} exited with code ${code}`));});
});
function safePackage(v){return typeof v==='string'&&/^[a-zA-Z][a-zA-Z0-9_]*(\.[a-zA-Z][a-zA-Z0-9_]*){1,}$/.test(v)&&v.length<=120;}
function safeName(v){return String(v||'My Web App').replace(/[<>:"/\\|?*\x00-\x1f]/g,'').trim().slice(0,40)||'My Web App';}
async function copyZipWebsite(buffer,dest){
 const zip=new AdmZip(buffer), entries=zip.getEntries();
 if(entries.length>5000)throw new Error('ZIP contains too many files (limit 5000).');
 const root=path.resolve(dest);
 let total=0, foundIndex=false;
 for(const e of entries){
  if(e.isDirectory)continue;
  const name=e.entryName.replace(/\\/g,'/');
  if(name.startsWith('/')||name.split('/').includes('..'))throw new Error('ZIP contains an unsafe file path.');
  const data=e.getData();total+=data.length;if(total>100*1024*1024)throw new Error('Expanded website is too large (100 MB max).');
  let rel=name;
  if(rel.startsWith('__MACOSX/'))continue;
  const target=path.resolve(root,rel);if(!target.startsWith(root+path.sep))throw new Error('Unsafe ZIP path.');
  await fs.mkdir(path.dirname(target),{recursive:true});await fs.writeFile(target,data);
 }
 // If index.html is one directory deep, use that directory as the site root.
 try{await fs.access(path.join(root,'index.html'));foundIndex=true;}catch{}
 if(!foundIndex){
  const dirs=await fs.readdir(root,{withFileTypes:true});
  const candidates=dirs.filter(d=>d.isDirectory()&&d.name!=='__MACOSX');
  for(const d of candidates){try{await fs.access(path.join(root,d.name,'index.html'));const nested=path.join(root,d.name);for(const item of await fs.readdir(nested))await fs.rename(path.join(nested,item),path.join(root,item));await fs.rm(nested,{recursive:true,force:true});foundIndex=true;break;}catch{}}
 }
 if(!foundIndex)throw new Error('ZIP must contain index.html at its root or one folder deep.');
}
async function createIcon(iconBuffer,androidRes){
 const sizes={ 'mipmap-mdpi':48,'mipmap-hdpi':72,'mipmap-xhdpi':96,'mipmap-xxhdpi':144,'mipmap-xxxhdpi':192 };
 for(const [folder,size] of Object.entries(sizes)){
  const dir=path.join(androidRes,folder);await fs.mkdir(dir,{recursive:true});
  const out=await sharp(iconBuffer).resize(size,size,{fit:'contain',background:{r:0,g:0,b:0,alpha:0}}).png().toBuffer();
  await fs.writeFile(path.join(dir,'ic_launcher.png'),out);await fs.writeFile(path.join(dir,'ic_launcher_round.png'),out);
 }
}
app.post('/api/build',upload.fields([{name:'website',maxCount:1},{name:'icon',maxCount:1}]),async(req,res)=>{
 let tmp='';
 try{
  const website=req.files?.website?.[0],icon=req.files?.icon?.[0];
  if(!website) return res.status(400).json({error:'Upload an HTML file or ZIP website bundle.'});
  const ext=path.extname(website.originalname).toLowerCase();
  if(!['.html','.htm','.zip'].includes(ext))return res.status(400).json({error:'Website must be .html, .htm or .zip.'});
  const appName=safeName(req.body.appName),packageId=req.body.packageId;
  if(!safePackage(packageId))return res.status(400).json({error:'Invalid package ID. Example: com.example.myapp'});
  if(icon){const kind=await fileTypeFromBuffer(icon.buffer);if(!kind||!['image/png','image/jpeg','image/webp'].includes(kind.mime))return res.status(400).json({error:'Icon must be a valid PNG, JPG or WebP image.'});}
  tmp=path.join(os.tmpdir(),'apkforge-'+crypto.randomUUID());await fs.mkdir(tmp,{recursive:true});
  const site=path.join(tmp,'site');await fs.mkdir(site);
  if(ext==='.zip')await copyZipWebsite(website.buffer,site);
  else {if(!/<html[\s>]/i.test(website.buffer.toString('utf8').slice(0,100000)))return res.status(400).json({error:'File does not look like a valid HTML document.'});await fs.writeFile(path.join(site,'index.html'),website.buffer);}
  const project=path.join(tmp,'project');await fs.mkdir(project);
  await fs.writeFile(path.join(project,'package.json'),JSON.stringify({name:'apkforge-temporary-app',version:'1.0.0',private:true,type:'module',dependencies:{'@capacitor/core':'^7.4.3','@capacitor/cli':'^7.4.3','@capacitor/android':'^7.4.3'}}));
  await fs.writeFile(path.join(project,'capacitor.config.json'),JSON.stringify({appId:packageId,appName,webDir:'www',bundledWebRuntime:false,server:{androidScheme:'https'}}));
  await fs.mkdir(path.join(project,'www'));for(const item of await fs.readdir(site))await fs.rename(path.join(site,item),path.join(project,'www',item));
  // Capacitor needs index.html in the web root.
  await run('npm',['install','--no-audit','--no-fund'],project,4*60*1000);
  await run('npx',['cap','add','android'],project,4*60*1000);
  const android=path.join(project,'android');
  if(icon){
   const resDir=path.join(android,'app','src','main','res');await createIcon(icon.buffer,resDir);
   const manifest=path.join(android,'app','src','main','AndroidManifest.xml');
   let xml=await fs.readFile(manifest,'utf8');xml=xml.replace(/android:icon="@mipmap\/ic_launcher"/g,'android:icon="@mipmap/ic_launcher"').replace(/android:roundIcon="@mipmap\/ic_launcher_round"/g,'android:roundIcon="@mipmap/ic_launcher_round"');await fs.writeFile(manifest,xml);
  }
  await run('npx',['cap','sync','android'],project,4*60*1000);
  await run('./gradlew',['assembleDebug','--no-daemon'],android,8*60*1000);
  const apk=path.join(android,'app','build','outputs','apk','debug','app-debug.apk');
  const bytes=await fs.readFile(apk);
  res.setHeader('Content-Type','application/vnd.android.package-archive');
  res.setHeader('Content-Disposition',`attachment; filename="${appName.replace(/[^a-z0-9_-]/gi,'_')}.apk"`);
  res.setHeader('Content-Length',bytes.length);res.send(bytes);
 }catch(e){console.error('Build failed:',e);if(!res.headersSent)res.status(500).json({error:String(e.message||'Build failed').slice(0,1500)});}
 finally{if(tmp)await fs.rm(tmp,{recursive:true,force:true}).catch(()=>{});}
});
app.use((err,req,res,next)=>{if(err instanceof multer.MulterError)return res.status(413).json({error:err.code==='LIMIT_FILE_SIZE'?`Upload too large. Maximum is ${MAX_MB} MB.`:'Too many uploaded files.'});console.error(err);res.status(500).json({error:'Unexpected server error.'});});
app.listen(PORT,()=>console.log(`APKForge API listening on ${PORT}`));
